﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class NumAdd8 : RandomNumber
{
    public Text LatestNumber8;

    void OnTriggerEnter(Collider other)
    {
        total = total + 8;
        LatestNumber8.text = "                                                     +" + total;

    }

}