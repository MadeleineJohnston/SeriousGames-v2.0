﻿/*using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class Health : MonoBehaviour {

	public ImagePosition healthBar;
	public float health;
	public GameObject restart;

	GameObject g = GameObject.Find("TimeBar");
	CountdownTimer bScript = g.GetComponent<CountdownTimer>() ;

	// Use this for initialization
	void Start () {
		showRestart(false);
	}
	
	// Update is called once per frame
	void Update () {
		checkHealth ();
	}


	void checkHealth(){
		
		if (health <= 0.0f){
			showRestart (true);
		}
	}
		
	void healthLoss(){
		if (bScript.timeLeft == 0) {
			subtractHealth (30.0f);
		}
	}

	public void subtractHealth (float amount) {
		if (health - amount < 0.0f) {
			health = 0.0f;
		} else {
			health -= amount;
		}
	}



	public void showRestart(bool c){

		if (c) {
			Time.timeScale = 0.0f;
		}
		else{
			Time.timeScale = 1.0f;
		}
		restart.SetActive (c);
	}

	public void Restart(){
		Application.LoadLevel ("main");
	}
}*/