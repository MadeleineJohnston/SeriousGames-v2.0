﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

[System.Serializable]
public class Boundary
{
    public float xMin, xMax, zMin, zMax;
}

public class PlayerController : MonoBehaviour {
    private Rigidbody rb;
    public float speed;
    public float tilt;
	private Vector3 RelativeRotation;
    public Boundary boundary;
	public float posX = 6.0f;
	public float posz = 2.0f;

        void Start()
    {
        rb = GetComponent<Rigidbody>();
    }

	void FixedUpdate ()
	{
		float moveHorizontal = Input.GetAxis ("Horizontal");
		float moveVertical = Input.GetAxis ("Vertical");

		Vector3 movement = new Vector3 (moveHorizontal, 0.0f, moveVertical);
		rb.velocity = movement * speed;
		//transform.rotation = Quaternion.LookRotation(RelativeRotation);

		if (Input.GetKey ("escape")) {
			Application.Quit ();
		}
	
		rb.position = new Vector3 (
			Mathf.Clamp (rb.position.x, boundary.xMin, boundary.xMax), 
			0.0f, 
			Mathf.Clamp (rb.position.z, boundary.zMin, boundary.zMax)
		);

	}
		void OnTriggerEnter (Collider other)
		{
			if (other.gameObject.CompareTag ("Collide"))
			{
				other.gameObject.SetActive (false);
			//transform.position.x = (6);
			//transform.position.z = (2);
		
			}
		}

}
