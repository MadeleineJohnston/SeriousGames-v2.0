﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class NumberAdder2 : RandomNumber
{
    
        void Start()
    {
        totalScore.text = "+ 2";
    }

    void OnTriggerExit(Collider other)
    {
        total = total + 2;
    }


}