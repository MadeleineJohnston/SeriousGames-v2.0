﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class NumberAdder : RandomNumber
{

    void Start()
    {
        totalScore.text = "+ 1";
    }


    void OnTriggerExit(Collider other)
    {
        total = total + 1;
    }

}