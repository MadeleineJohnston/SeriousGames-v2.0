﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.SceneManagement;
using SimpleJSON;


public class Exit : MonoBehaviour {

	private const int idSG = 356;

	public Button exitText;
	public GameObject Ready;
	public int levelNum = 1;
	public Text txtUsername;
	public InputField txtPassword;
	public InputField inputPrefab;
	public GameObject inputParent;
	private List<InputField> inputFields = new List<InputField> ();

	private static string username;
	private static string password;



		void Update() {
		if (Input.GetKey ("escape")) {
			Application.Quit ();

		}
	}
		
	void Start () {

		exitText = exitText.GetComponent<Button> ();
		Scene currentScene = SceneManager.GetActiveScene ();
		string sceneName = currentScene.name;

		if (sceneName == "main") {
			levelNum += 0;
		} else if (sceneName == "main2") {
			levelNum += 1;
		} else if (sceneName == "main3") {
			levelNum += 1;
		} else if (sceneName == "Parameter") {

			int i = 0;

		/*	foreach (JSONNode param in EngAGe.E.getParameters ())
			{
				InputField inputParam = (InputField)Instantiate (inputPrefab);
				inputParam.name = "input_" + param["name"];
				inputParam.transform.SetParent (inputParent.transform);
				inputParam.text = param ["question"];

				RectTransform transform = inputParam.transform as RectTransform;
				transform.anchoredPosition = new Vector3 (0, 20 - i*50);

				inputFields.Add (inputParam);
				i++;
			}*/

		}else {
			levelNum = +0;
		}

	}

	public void ExitGame(){

		SceneManager.LoadScene("Main Menu");

	}

	public void GetStarted()
	{
		username = txtUsername.text;
		password = txtPassword.text;

		//StartCoroutine (EngAGe.E.loginStudent (idSG, username, password, "Login", "Main Menu", "Parameter"));
		SceneManager.LoadScene("Parameter");
	}	

	public void GetStartedGuest()
	{
		//StartCoroutine(EngAGe.E.guestLogin(idSG,"LoginScene","Parameter"));
		SceneManager.LoadScene("Parameter");
	}

	public void MainMenu()
	{

	/*	foreach (JSONNode param in EngAGe.E.getParameters()) {
			foreach (InputField inputField in inputFields) {
				if (inputField.name == "input_" + param ["name"]) {
					param.Add ("value", inputField.text);
				}
			}
		}*/
		SceneManager.LoadScene("Main Menu");
	}

	public void Load2(){

		SceneManager.LoadScene("main2");

	}

	public void Load3(){

		SceneManager.LoadScene("main3");

	}

	public void Play(){
		Time.timeScale = 1;
		Ready.SetActive (false);
	}

	public void Win(){

		if (levelNum == 1) {
			SceneManager.LoadScene ("main");
		}
		else if (levelNum == 2) {
			SceneManager.LoadScene ("main2");
		}
		else if (levelNum == 3) {
			SceneManager.LoadScene ("main3");
		}

	}

}
