﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class NumAdd9 : RandomNumber
{
    public Text LatestNumber9;

    void OnTriggerEnter(Collider other)
    {
        total = total + 9;
        LatestNumber9.text = "                                                                                     +" + total;

    }

}