﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class NumAdd6 : RandomNumber
{
    public Text LatestNumber6;

    void OnTriggerEnter(Collider other)
    {
        total = total + 6;
        LatestNumber6.text = "           +" + total;

    }

}