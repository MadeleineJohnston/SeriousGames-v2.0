﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;


public class Exit : MonoBehaviour {
	
	public class ExitClass : MonoBehaviour {
		void Update() {
			if (Input.GetKey("escape"))
				Application.Quit();

		}
	}

	public Button exitText;

	void Start () {

		exitText = exitText.GetComponent<Button> ();

	}

	public void ExitGame(){

		Application.Quit ();

	}
}
