﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class NumAdd5 : RandomNumber
{
    public Text LatestNumber5;

    void OnTriggerEnter(Collider other)
    {
        total = total + 5;
        LatestNumber5.text = "                                                                +" + total;

    }

}