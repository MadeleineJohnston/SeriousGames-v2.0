﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

using UnityEngine.EventSystems;

public class Calculator : MonoBehaviour
{
    [SerializeField]
    public Text inputField;

    string inputString; // buttonValue;
    int[] number = new int[9];      //store up to 9 numbers
    string operatorSymbol;
    int i = 0;
    float result;

    public void ButtonPressed()
    {
        //Debug.Log(EventSystem.current.currentSelectedGameObject.name);

        string buttonValue = EventSystem.current.currentSelectedGameObject.name;

        int arg;
        //if int then assign to arg - uses Parser to make a value int
        if (int.TryParse(buttonValue, out arg))
        {
            if (i > 1) i = 0;
            number[i] = arg;
            i = i++;
        }
        else
        {
            switch (buttonValue)
            {
                case "+":
                    operatorSymbol = buttonValue;
                    break;
                case "-":
                    operatorSymbol = buttonValue;
                    break;
                case "/":
                    operatorSymbol = buttonValue;
                    break;
                case "*":
                    operatorSymbol = buttonValue;
                    break;
                case "=":
                    result = number[i];
                    break;
            }

            number = new int[9];
        }


        inputString += buttonValue;
        inputString = (!result.Equals("")) ? inputString + result : inputString; 
    
        inputField.text = "+" + buttonValue;
    }
}