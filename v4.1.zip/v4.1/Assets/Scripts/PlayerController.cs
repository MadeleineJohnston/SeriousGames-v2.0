﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;
using UnityEngine.UI;

[System.Serializable]
public class Boundary
{
    public float xMin, xMax, zMin, zMax;
}

public class PlayerController : MonoBehaviour {
    private Rigidbody rb;
    public float speed;
    public float tilt;
	private Vector3 RelativeRotation;
    public Boundary boundary;
	public float posX = 10.0f;
	public float posz = 2.0f;
	public GameObject Cube1A;
	public GameObject Cube2A;
	public GameObject Cube3A;
	public GameObject Cube4A;
	public GameObject Cube5A;
	public GameObject Cube6A;
	public GameObject Cube7A;
	public GameObject Cube8A;
	public GameObject Cube9A;
	public GameObject Cube50A;
	public GameObject CubeAdd;
	public GameObject CubeSubtract;
	public GameObject CubeDivide;
	public GameObject CubeMultiply;
	public GameObject Divide;
	public GameObject Add;
	public GameObject Subtract;
	public GameObject Multiply;
	public GameObject Equals;
	public GameObject Win;
	public GameObject Loss;
	public Text GoalNumber;
	public Text CurrentNumber;
	public Text CurrentNumber1;
	public Text CurrentNumber2;

	int sum = 0;
	int x = 0;
	int type = 0;
	int sum1;
	int sum2;
	int sum3;


	int NumPosX = -7;
	int NumPosZ = -2;
	int addCount = 0;
	int subtractCount = 0;
	int divideCount = 0;
	int multiplyCount = 0;
	int randInt;
	int result;
	int valInt;

	string val;
	int temp;
	bool endOfCalc;

        void Start()
    {
        rb = GetComponent<Rigidbody>();
		randInt = Random.Range(100, 500);
		//randInt = 118;
		GoalNumber.text = "" + randInt;
		val = "";
		endOfCalc = false;
    }

	void FixedUpdate ()
	{
		//float moveHorizontal = Input.GetAxis ("Horizontal");
		//float moveVertical = Input.GetAxis ("Vertical");

		var moveHorizontal = Input.GetAxis("Horizontal") * Time.deltaTime * 150.0f;
		var moveVertical = Input.GetAxis("Vertical") * Time.deltaTime * 3.0f;

		//Vector3 movement = new Vector3 (moveHorizontal, 0.0f, moveVertical);
		//rb.velocity = movement * speed;
		//transform.rotation = Quaternion.LookRotation(RelativeRotation);
		transform.Rotate(0,0,-moveHorizontal);
		transform.Translate(0, moveVertical, 0);

		if (Input.GetKey ("escape")) {
			Application.Quit ();
		}
	
		rb.position = new Vector3 (
			Mathf.Clamp (rb.position.x, boundary.xMin, boundary.xMax), 
			0.0f, 
			Mathf.Clamp (rb.position.z, boundary.zMin, boundary.zMax)
		);

		if (Input.GetKeyDown (KeyCode.R))
			SceneManager.LoadScene ("main");
		

	}

	void Calculation(string str){
		if(!endOfCalc)
			val += str;
		else{
			val = "";
			val += str;
			endOfCalc = false;
			temp = 0;
		}
	}


		void OnTriggerEnter (Collider other)
	{
		if (other.gameObject.CompareTag ("Collide")) {
			other.gameObject.SetActive (false);
			Cube1A.SetActive (true);
			Cube1A.transform.position = new Vector3 (NumPosX, 0, NumPosZ);
			NumPosX += 1;
			//Calculation ("1");
			//if (x > 0)
		//		y = 1;
		//	else if (x < 1)
		//		x = 1;
			if (type == 0)
				sum += 1;
			else if (type == 1)
				sum -= 1;
			else if (type == 2)
				sum /= 1;
			else if (type == 3)
				sum *= 1;
		} else if (other.gameObject.CompareTag ("Collide2")) {
			other.gameObject.SetActive (false);
			Cube2A.SetActive (true);
			Cube2A.transform.position = new Vector3 (NumPosX, 0, NumPosZ);
			NumPosX += 1;	
			//Calculation ("2");
			//if (x > 0)
			//	y = 2;
			//else if (x < 1)
			if (type == 0)
				sum += 2;
			else if (type == 1)
				sum -= 2;
			else if (type == 2)
				sum /= 2;
			else if (type == 3)
				sum *= 2;
		} else if (other.gameObject.CompareTag ("Collide3")) {
			other.gameObject.SetActive (false);
			Cube3A.SetActive (true);
			Cube3A.transform.position = new Vector3 (NumPosX, 0, NumPosZ);
			NumPosX += 1;	
			//Calculation ("3");
			if (type == 0)
				sum += 3;
			else if (type == 1)
				sum -= 3;
			else if (type == 2)
				sum /= 3;
			else if (type == 3)
				sum *= 3;
		} else if (other.gameObject.CompareTag ("Collide4")) {
			other.gameObject.SetActive (false);
			Cube4A.SetActive (true);
			Cube4A.transform.position = new Vector3 (NumPosX, 0, NumPosZ);
			NumPosX += 1;	
			//Calculation ("4");
			if (type == 0)
				sum += 4;
			else if (type == 1)
				sum -= 4;
			else if (type == 2)
				sum /= 4;
			else if (type == 3)
				sum *= 4;
		} else if (other.gameObject.CompareTag ("Collide5")) {
			other.gameObject.SetActive (false);
			Cube5A.SetActive (true);
			Cube5A.transform.position = new Vector3 (NumPosX, 0, NumPosZ);
			NumPosX += 1;
			//Calculation ("5");
			if (type == 0)
				sum += 5;
			else if (type == 1)
				sum -= 5;
			else if (type == 2)
				sum /= 5;
			else if (type == 3)
				sum *= 5;
		} else if (other.gameObject.CompareTag ("Collide6")) {
			other.gameObject.SetActive (false);
			Cube6A.SetActive (true);
			Cube6A.transform.position = new Vector3 (NumPosX, 0, NumPosZ);
			NumPosX += 1;
			//Calculation ("6");
			if (type == 0)
				sum += 6;
			else if (type == 1)
				sum -= 6;
			else if (type == 2)
				sum /= 6;
			else if (type == 3)
				sum *= 6;
		} else if (other.gameObject.CompareTag ("Collide7")) {
			other.gameObject.SetActive (false);
			Cube7A.SetActive (true);
			Cube7A.transform.position = new Vector3 (NumPosX, 0, NumPosZ);
			NumPosX += 1;
			//Calculation ("7");
			if (type == 0)
				sum += 7;
			else if (type == 1)
				sum -= 7;
			else if (type == 2)
				sum /= 7;
			else if (type == 3)
				sum *= 7;
		} else if (other.gameObject.CompareTag ("Collide8")) {
			other.gameObject.SetActive (false);
			Cube8A.SetActive (true);
			Cube8A.transform.position = new Vector3 (NumPosX, 0, NumPosZ);
			NumPosX += 1;
			//Calculation ("8");
			if (type == 0)
				sum += 8;
			else if (type == 1)
				sum -= 8;
			else if (type == 2)
				sum /= 8;
			else if (type == 3)
				sum *= 8;
		} else if (other.gameObject.CompareTag ("Collide9")) {
			other.gameObject.SetActive (false);
			Cube9A.SetActive (true);
			Cube9A.transform.position = new Vector3 (NumPosX, 0, NumPosZ);
			NumPosX += 1;
			//Calculation ("9");
			if (type == 0)
				sum += 9;
			else if (type == 1)
				sum -= 9;
			else if (type == 2)
				sum /= 9;
			else if (type == 3)
				sum *= 9;
		} else if (other.gameObject.CompareTag ("Collide50")) {
			other.gameObject.SetActive (false);
			Cube50A.SetActive (true);
			Cube50A.transform.position = new Vector3 (NumPosX, 0, NumPosZ);
			NumPosX += 1;
			//Calculation ("50");
			if (type == 0)
				sum += 50;
			else if (type == 1)
				sum -= 50;
			else if (type == 2)
				sum /= 50;
			else if (type == 3)
				sum *= 50;
	}
	}

	public void AddButton(){
		if (addCount < 2) {
			CubeAdd.SetActive (true);
			CubeAdd.transform.position = new Vector3 (NumPosX, 0, NumPosZ);
			NumPosX += 1;	
			addCount += 1;
			//temp +=int.Parse(val);
			//val = "";
			//if (x > 0 && y > 0)
			//	sum += x + y;
			//x = 0;
			//y = 0;
			//if (x > 0)
			//sum += x;
			//x = 0;
			type = 0;
		}else
			Add.SetActive (false);
	}

	public void SubtractButton(){
		if (subtractCount < 2) {
		CubeSubtract.SetActive (true);
		CubeSubtract.transform.position = new Vector3 (NumPosX, 0, NumPosZ);
		NumPosX += 1;	
		subtractCount += 1;
			//temp -=int.Parse(val);
			//val = "";
			//if (x > 0)
			//	sum -= x;
			//x = 0;
			type = 1;
		}else
			Subtract.SetActive (false);
	}

	public void DivideButton(){
		if (divideCount < 2) {
			CubeDivide.SetActive (true);
			CubeDivide.transform.position = new Vector3 (NumPosX, 0, NumPosZ);
			NumPosX += 1;
			divideCount += 1;
			//temp /=int.Parse(val);
			//val = "";
			//if (x > 0)
			//	sum /= x;
			//x = 0;
			type = 2;
		}else
			Divide.SetActive (false);
	}

	public void MultiplyButton(){
		if (multiplyCount < 2) {
			CubeMultiply.SetActive (true);
			CubeMultiply.transform.position = new Vector3 (NumPosX, 0, NumPosZ);
			NumPosX += 1;	
			multiplyCount += 1;
		//	temp *=int.Parse(val);
		//	val = "";
			//if (x > 0)
			//	sum *= x;
			//x = 0;
			type = 3;
		}else
			Multiply.SetActive (false);
			
	}

	public void EqualsButton(){

	//	temp +=int.Parse(val);
	//	val = temp.ToString();
	//	endOfCalc = true;
	//	int.TryParse (val, out valInt);
	//Loss.SetActive (true);
			if (sum1 < 1) {
				sum1 = sum;
				sum = 0;
			} else if (sum1 > 0) {
				sum2 = sum;
				sum = 0;
				sum1 = sum1 + sum2;
		} else if (sum1 > 0 && sum2 > 0) {
			sum3 = sum;
			sum = 0;
			sum1 = sum1 + sum2 + sum3;
		}

	}

	public void FinishedButton(){
		if (randInt == sum1 || randInt == sum1 || randInt == sum2 || randInt == sum3) {
			Time.timeScale = 0;
			Win.SetActive (true);
		}
	}

	public void Update(){
		CurrentNumber.text = "" + sum;
		CurrentNumber2.text = "" + sum1;
		CurrentNumber1.text = "" + sum2;
	}
	/*void checkWin()
	{
		
		if (result == valInt && endOfCalc == true) {
			Time.timeScale = 0;
			Win.SetActive (true);
		} else
			SceneManager.LoadScene ("main");
	}*/
}
