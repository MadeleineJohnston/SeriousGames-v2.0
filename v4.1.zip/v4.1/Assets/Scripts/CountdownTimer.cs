﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.SceneManagement;

public class CountdownTimer : MonoBehaviour {

	Image fill;
	float timeAmount = 10;
	float time;
	public Text countdownText;
	public const int maxHealth = 100;
	public int currentHealth = maxHealth;
	public RectTransform healthBar;
	public GameObject Crash;
	public int levelNum = 1;
	bool timeLow = false;

	// Use this for initialization
	void Start () {

		fill = this.GetComponent<Image> ();
		time = timeAmount;
		Time.timeScale = 0;


		Scene currentScene = SceneManager.GetActiveScene ();
		string sceneName = currentScene.name;

		if (sceneName == "main") {
			
				timeAmount = 90.02f;
				time = timeAmount;
			 		
		} else if (sceneName == "main2") {
			
				timeAmount = 100.02f;
				time = timeAmount;

		} else if (sceneName == "main3") {
			
				timeAmount = 120.02f;
				time = timeAmount;
			}	
		}

	public void decreaseTime(){

		timeLow = true;

	}


	public void TakeDamage(int amount){

		currentHealth -= amount;
		if (currentHealth <= 0) {
			currentHealth = 0;
		}

		healthBar.sizeDelta = new Vector2( currentHealth, healthBar.sizeDelta.y);
	}
	
	// Update is called once per frame
	void Update () {

		if (time > 0) {
			time -= Time.deltaTime;
			fill.fillAmount = time / timeAmount;
			countdownText.text = "Time: " + time.ToString ("F");
		}

		if (time <= 0) {
			TakeDamage (2);
		}
			
		if (currentHealth <= 0) {
			Crash.SetActive (true);
		}

		if (time <= 0) {
			Time.timeScale=0;
		}

		if (timeLow == true) {
			timeAmount = timeAmount - 10.00f;
			time = timeAmount;
		}
	}
		
}
