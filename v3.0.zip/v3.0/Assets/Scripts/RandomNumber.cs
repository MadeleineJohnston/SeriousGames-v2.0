﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class RandomNumber : MonoBehaviour
{

    public Text GoalNumber;
    public Text Match;
    public Text totalScore;
    public float randomInt;
    public float total = 0; //total of numbers already collected

    // Use this for initialization
    void Start()
    {

        randomInt = Random.Range(100, 1000);

        GoalNumber.text = "" + randomInt;
        totalScore.text = "Total Numbers: " + total;
    }

    void Update()
    {

        if (total == randomInt)
        {
            Match.text = "The numbers match. Congrats!";
        }
    }

}
