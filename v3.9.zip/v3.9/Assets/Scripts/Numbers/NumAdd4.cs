﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class NumAdd4 : RandomNumber
{
    public Text LatestNumber4;

    void OnTriggerEnter(Collider other)
    {
        total = total + 4;
        LatestNumber4.text = "                                              +" + total;

    }

}