﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class NumAdd7 : RandomNumber
{
    public Text LatestNumber7;

    void OnTriggerEnter(Collider other)
    {
        total = total + 7;
        LatestNumber7.text = "                          +" + total;

    }

}