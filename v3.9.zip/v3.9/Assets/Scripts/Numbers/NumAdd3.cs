﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class NumAdd3 : RandomNumber
{
    public Text LatestNumber3;

    void OnTriggerEnter(Collider other)
    {
        total = total + 3;
        LatestNumber3.text = "                              +" + total;

    }

}