﻿//using System.Collections;
//using System.Collections.Generic;
//using UnityEngine;
//using UnityEngine.UI;
//using System;

//public class Calculator : MonoBehaviour
//{

//    Text resultText;
//    double result = 0.0;
//    double tempSave;
//    string operation;
//    double multiplier = 1;
//    public double storeInt;

//    public Button addB;

//    // Use this for initialization
//    void Start()
//    {
//        resultText = GameObject.Find("Result").GetComponent<Text>();
//    }

//    // Update is called once per frame
//    void Update()
//    {

//    }

//    public void writeToTextField()
//    {
//        resultText.text = "" + result;
//    }

//    public void ClearResult()
//    {
//        result = 0.0;
//        multiplier = 1;
//        writeToTextField();
//    }

//    public void saveOperation(string 0)
//    {
//        operation = operation;
//        tempSave = rsult;
//        result = 0.0;
//        multiplier = 1;
//        //displays operation character
//        resultText.text = operation;
//    }


//    public void addNumber(int d)
//    {
//        if (multiplier == 1)
//        {
//            result *= 10;
//            result += d;
//        }
//        else
//        {
//            result += d * multiplier;
//            multiplier /= 10;
//        }

//        writeToTextField();
//    }

//    public void setMultiplier()
//    {
//        setMultiplier = 0.1;
//    }

//    public void CalcResult()
//    {

//        switch (operation)
//        {
//            case "+":
//                result = tempSave + result;
//                break;
//            case "-":
//                result = tempSave - result;
//                break;
//            case "*":
//                result = tempSave * result;
//                break;
//            case "/":
//                result = tempSave / result;
//                break;
//        }

//        if (operation == "store")
//            storeInt = tempSave;
//        else if (operation == "restore")
//            result = storeInt;


//        //clear the operation
//        operation = "";
//        //setMultiplier = 1;

//        writeToTextField();
//    }

//}

//using System.Collections;
//using System.Collections.Generic;
//using UnityEngine;
//using UnityEngine.UI;

//public class calculator : RandomNumber
//{
  //  public Text LatestNumber;

    //void OnButtonPress(Button x)
    //{
     //   total++;
      //  LatestNumber.text = "+" + total;
    //}

//}