﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;


public class Exit : MonoBehaviour {

	public Button exitText;
	public GameObject Ready;

	

		void Update() {
		if (Input.GetKey ("escape")) {
			Application.Quit ();

		}
	}


	
	


	void Start () {

		exitText = exitText.GetComponent<Button> ();

	}

	public void ExitGame(){

		//Application.Quit ();
		Application.LoadLevel("Main Menu");
		//SceneManager.LoadScene("Main Menu");

	}

	public void Play(){
		Time.timeScale = 1;
		Ready.SetActive (false);
	}

}
