﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class NumberAdder2 : RandomNumber
{
    public Text LatestNumber2;

    void OnTriggerEnter(Collider other)
    {
        total = total +2;
        LatestNumber2.text = "              +" + total;

    }

}